TTNFSS packages version 1.3 2000/09/05 provided by Yoshiki OTOBE:
	!!! YOU NEED dviout version 3.11.5 later !!!

The Original site that distributes TTNFSS packages:
Simple document (Japanese only)
http://ms326.ms.u-tokyo.ac.jp/otobe/tex/fontproj.html
Minimum distribution (same as included in dviout)
http://ms326.ms.u-tokyo.ac.jp/otobe/tex/files/ttnfss/ttmin13.lzh
Standard package (Windows common fonts)
http://ms326.ms.u-tokyo.ac.jp/otobe/tex/files/ttnfss/winttf13.lzh
For Windows95 series additional fonts
http://ms326.ms.u-tokyo.ac.jp/otobe/tex/files/ttnfss/win98_13.lzh
For WindowsNT/2000 series additional fonts
http://ms326.ms.u-tokyo.ac.jp/otobe/tex/files/ttnfss/win2k_13.lzh

1. Introduction.
As PSNFSS packages, this provides a way to use TrueType fonts.
You need to have a previewer which can show TrueType fonts.
There might be several softwares which can treat TrueType fonts,
we intended to use them with T. Oshima's dviout.

DVIOUT is one of the strongest DVI driver on Windows platform,
which had also been strongest on MS-DOS.
After Version 3.08 it became possible to treat virtual fonts,
which may be necessary functions to treat TrueType to create
beautiful documents.
Needless to say, since almost TrueType fonts have same encoding vector,
it is not essential to treat them with Virtual Font technology,
that is, dviout can treat BaKoMa and Impress corp.'s Computer Modern
TrueType fonts without Virtual Font mechanism even those have
different encodings from Knuth's original ones.
However, it is true that almost all macro packages implicitly assume
that a font have Knuth's encodings.
Those macros wouldn't work correctly if a font have different encodings
from Knuth's ones.
It is all reason why we want Virtual Font mechanism for text fonts
provided by TrueType.
Of course it is essential if we use them in MATH mode.
Since usual TrueType fonts don't have enough symbols to express
higher mathematical formulas, we need help of Computer Modern or
equivalently well-designed math-oriented fonts.
We, then, have to mix the fonts to express mathematical formulas
with a given text font.
It means that we essentially need Virtual Font mechanism.

2. Usage
When you want to create your beautiful documents with TrueType fonts,
only you have to do is that
	\usepackage{timesnew}
on the preamble of the source file.
Then, as a default, that assumes T1 encodings,
use Times New Roman as roman, Arial as sans-serif, Courier New as Typewriter.
If you want to use OT1 (7bit) encoding, you specify an optional argument,
	\usepackage[OT1]{timesnew}

Windows' encodings are based on Latin-1, it is enough to express
Western European languages. They don't have enough accent characters.
It is better for you to use T1 encoding.

There are several packages:
	timesnew: Times New Roman, Arial, Courier New
	arial:    Arial (sans-serif default)
	comicsans: Comic Sans as sans-serif
	couriernew: Courier New (typewriter default)
	georgia: Georgia (roman default)
	impact: Impact (typewriter default)
	mssans: Microsoft's Sans Serif (sans-serif default)
	sylfaen: Sylfaen (roman default)
	tahoma: Tahoma (sans-serif default)
	trebuchet: Trebuchet (sans-serif default)
	verdana: Verdana (sans-serif default)
	palatino: Palatino, Verdana, Courier New

3. mathwns package
When you declare:
	\usepackage{mathwns}
then, this package tries to use Times New Roman and Symbol fonts
to express mathematical formulas, which is quite similar with
mathptmx packages.
Since there is no font such as a Zapf's Chancery,
it is impossible to be similar with mathptm packages.
There could be found several improvements from mathptmx.

mathwns package also changes default roman font as Times New Roman.

4. winpi package
Like pifonts package in PSNFSS, which provides a method to access
misc. symbol fonts.
However, there is no Zapf's Dingbats fonts in Windows default,
we use Wingdings fonts.

Notice that following families (U-encoding) are defined:
wsy: Simbol
wpi: Monotype Sorts
wmswd: WingDings
wmswd2: WingDings2
wmswd3: WingDings3
wmsd: Webdings
wmsml: Marlett

You can obtain a table from TeXing testfont.tex with:
wsyr:    Symbol
wpi313:  Monotype Sorts
wmsdr:   Webdings
wmswdr:  WingDings
wmswdr2: WingDings 2
wmswdr3: WingDings 3
wmsmlt:  Marlett

\Pisymbol{wsy}{"BF} : use Symbol
\ding{"2E}    : use Monotype Sorts <=> Zapf Dingbats
\dinga{"2E}   : use WingDings
\dingb{"2E}   : use WingDings 2
\dingc{"2E}   : use WingDings 3
\webding{"2E} : use Webdings
\marlett{"2E} : use Marlett
\dingfill{"2E}    : fill with Monotype Sorts
\dingline{"2E}    : draw line with Monotype Sorts
(\dingafill, \dingaline, \dingbfill, \dingbline, \dingcfill, \dingcline
\webdingfill, \webdingline, \marlettfill, and \marlettline
are corresponding versions of WingDings, WingDings2, WingDings3, Webdings).
Also you can use
\begin{dinglist}{"2E}...\end{dinglist} and
\begin{dingaautolist}{"2E}...\end{dingautolist} environments,
dinga, dingb, dingc, webding and marlett versions also exist.
Notice that, for instance, \ding is a shorter version of \Pisymbol{wpi}
and so on.

You can obtain Monotype Sorts which is not a Windows' standard fonts
from, for instance, Microsoft's softwares such as Microsoft Office.
A list of softwares which contain Monotype Sorts is following:
	Access 97 SR2,
	Greetings 99,
	Home Publishing 99,
	Office 2000 Premium,
	Office 4.3 Professional,
	Office 97 Small Business Edition SR2,
	Office 97 SR1a,
	PhotoDraw 2000,
	Publisher 97,
	TrueType Font Pack
You can get a detailed information from
http://www.microsoft.com/typography/fonts/default.asp
The author does not check above application software packages
really contain Monotype Sorts. Ask Microsoft corp. or Monotype.

It is true that Monotype Sorts have a compatibility with
Zapf's Dingbats, it might be better for you to use
Microsoft's Dingbats font, which is a standard and contains
lots of useful symbols.

Finally, the author hopes you all could obtain a beautiful output
using this package. Happy TeXing.

6. Right
You all can treat all files, tfm/vf/map/sty/fd/tex and so on
contributed with TTNFSS, TOTALLY FREE.
You may redistribute a part or whole of files freely
without any permission for any purpose.
You may modify a part or whole of files or archives
without any permission.
You can use them for any purpose freely.
However, the author doesn't guarantee those packages are
useful, no bug and so on.
You MUST have any responsibility for using those files yourself.

Yoshiki OTOBE
Department of Mathematical Sciences
The University of Tokyo,
3-8-1 Komaba, Meguro-ku, Tokyo 153-8914, JAPAN.
